$(document).ready(function(){
	
	$(".category").mouseover(function(){
		$(".cate_list").stop().slideDown(500);
	}).mouseout(function(){
		$(".cate_list").stop().slideUp(500);
	});
	
	
	
});
