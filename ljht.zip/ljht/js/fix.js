var ngtotop = 240;
window.onload = function() {
	var ng = document.getElementById("airticle_bar");
	ngtotop += ng.offsetTop;
};
window.onscroll = function() {
	var ng = document.getElementById("airticle_bar");
	var i = document.body.scrollTop + document.documentElement.scrollTop;
	if (i <= ngtotop) {
		ng.setAttribute("style", "position:static");
	} else {
		ng.setAttribute("style", "position:fixed");
	}
}